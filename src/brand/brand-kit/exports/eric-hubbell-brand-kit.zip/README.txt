Eric Hubbell design kit
Serve this extracted folder with: python3 -m http.server 8766 --bind 127.0.0.1
Open http://127.0.0.1:8766/brand/brand-kit/
Fonts and licenses are included. Editable artwork is under brand/brand-kit/assets/.
